"""In-place (same-size) Dalvik bytecode patching helpers + dex checksum/signature fix-up."""
import hashlib, os, struct, sys, zlib

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from dexdis import Dex, disasm


class DexPatcher:
    def __init__(self, data):
        self.buf = bytearray(data)
        self.dex = Dex(bytes(data))
        self._methods = None

    # ---- lookups
    def string_idx(self, s):
        d = self.dex
        for i in range(d.str_n):  # linear scan; ~50k strings, decoded strings are cached by Dex
            if d.s(i) == s:
                return i
        return None

    def method_idx(self, sig):
        if self._methods is None:
            self._methods = {}
            for i in range(self.dex.meth_n):
                self._methods.setdefault(self.dex.method(i), i)
        return self._methods.get(sig)

    def find_code(self, sig):
        """Return (code_off, insns_off, n_units, tries, registers) for the method with this full signature."""
        d = self.dex
        target = self.method_idx(sig)
        if target is None:
            raise KeyError("method ref not found: " + sig)
        for cidx, sup, data in d.classes():
            for midx, acc, code in d.methods_of(data):
                if midx == target and code:
                    regs, ins, insns, n, tries = d.code(code)
                    return code, insns, n, tries, regs
        raise KeyError("method body not found: " + sig)

    def listing(self, sig):
        code, insns, n, tries, regs = self.find_code(sig)
        return disasm(Dex(bytes(self.buf)), insns, n)

    # ---- encoders
    @staticmethod
    def const_string(reg, sidx):
        assert reg < 256 and sidx < 65536
        return struct.pack("<HH", 0x1A | (reg << 8), sidx)

    @staticmethod
    def invoke(op, regs, midx):
        assert len(regs) <= 5 and all(r < 16 for r in regs)
        r = regs + [0] * (5 - len(regs))
        return struct.pack("<HHH", op | (len(regs) << 12) | (r[4] << 8), midx,
                           r[0] | (r[1] << 4) | (r[2] << 8) | (r[3] << 12))

    def write(self, insns_off, pc, blob):
        self.buf[insns_off + pc * 2: insns_off + pc * 2 + len(blob)] = blob

    def finish(self):
        sha = hashlib.sha1(self.buf[32:]).digest()
        self.buf[12:32] = sha
        self.buf[8:12] = struct.pack("<I", zlib.adler32(bytes(self.buf[12:])) & 0xFFFFFFFF)
        return bytes(self.buf)
