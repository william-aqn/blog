"""Patch every APK in a folder for Android 14/15 and verify each result.

Usage: python -I patch_all.py <src_dir> <out_dir> [--target 24]
Outputs <out_dir>/<name>_android15.apk; the signing key lives in <out_dir>/_key (reused on reruns,
so a re-patched APK installs as an update over the previous one).
"""
import os, sys, zipfile

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import patch_apk
import verify_apk

SUFFIX = "_android15.apk"
KEY_DIR = "_key"


def main(src, out, target):
    os.makedirs(out, exist_ok=True)
    out_abs = os.path.abspath(out)
    apks = []
    for root, dirs, files in os.walk(src):
        if os.path.abspath(root).startswith(out_abs):
            continue
        apks += [os.path.join(root, f) for f in sorted(files) if f.lower().endswith(".apk")]
    ok = bad = 0
    for apk in apks:
        name = os.path.basename(apk)
        if not zipfile.is_zipfile(apk):
            print("SKIP  %s: not a valid zip (broken/incomplete download)" % name)
            bad += 1
            continue
        dst = os.path.join(out, os.path.splitext(name)[0] + SUFFIX)
        try:
            old, report = patch_apk.patch(apk, dst, os.path.join(out, KEY_DIR), target)
        except Exception as e:
            print("FAIL  %s: %s" % (name, e))
            bad += 1
            continue
        fixes = sorted({k.split(" ")[0] for d in report.values() for k, v in d.items() if v == "applied"})
        passed = verify_apk.main(apk, dst)
        ok += passed
        bad += not passed
        print("      targetSdk %d -> %d, code fixes: %s" % (old, target, ", ".join(fixes) or "none"))
    print("\n%d ok, %d skipped/failed" % (ok, bad))
    return bad == 0


if __name__ == "__main__":
    a = sys.argv[1:]
    t = 24
    if "--target" in a:
        i = a.index("--target")
        t = int(a[i + 1])
        del a[i:i + 2]
    sys.exit(0 if main(a[0], a[1], t) else 1)
