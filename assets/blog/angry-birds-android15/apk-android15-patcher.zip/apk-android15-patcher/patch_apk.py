"""Patch an old APK so Android 14/15 will install it, then re-sign it (v1 + v2).

- AndroidManifest.xml: targetSdkVersion raised in place (binary AXML, same-size edit).
- Old signature files in META-INF are dropped; everything else is copied byte-for-byte
  (raw compressed data, no recompression), stored entries are 4-byte aligned (zipalign).
- v1 (JAR) signature: MANIFEST.MF / CERT.SF with SHA-256, CERT.RSA = CMS detached, made by OpenSSL.
- v2 (APK Signature Scheme v2) block, RSA PKCS#1 v1.5 + SHA-256 (algorithm 0x0103), made by OpenSSL.

Usage: python -I patch_apk.py <in.apk> <out.apk> <keydir> [--target 24]
"""
import base64, hashlib, os, re, shutil, struct, subprocess, sys, tempfile, zlib

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import axml
import fixes

GIT_OPENSSL = r"C:\Program Files\Git\mingw64\bin\openssl.exe"
OPENSSL = os.environ.get("OPENSSL") or shutil.which("openssl") or GIT_OPENSSL
ATTR_TARGET_SDK = 0x01010270


# ---------------------------------------------------------------- zip reading
class Entry:
    pass


def read_zip(data):
    eocd = data.rfind(b"PK\x05\x06", max(0, len(data) - 65557))
    if eocd < 0:
        raise ValueError("EOCD not found")
    (_, disk, cd_disk, n_disk, n_total, cd_size, cd_off, clen) = struct.unpack_from("<IHHHHIIH", data, eocd)
    if disk or cd_disk or n_disk != n_total or cd_off == 0xFFFFFFFF:
        raise ValueError("multi-disk / zip64 not supported")
    entries = []
    p = cd_off
    for _ in range(n_total):
        (sig, made_by, need, flags, method, mtime, mdate, crc, csize, usize, nlen, xlen, cmlen, dstart,
         iattr, eattr, loff) = struct.unpack_from("<IHHHHHHIIIHHHHHII", data, p)
        if sig != 0x02014B50:
            raise ValueError("bad central directory")
        e = Entry()
        e.name_bytes = data[p + 46:p + 46 + nlen]
        e.name = e.name_bytes.decode("utf-8" if flags & 0x800 else "cp437")
        e.flags, e.method, e.mtime, e.mdate = flags, method, mtime, mdate
        e.crc, e.csize, e.usize, e.eattr, e.made_by = crc, csize, usize, eattr, made_by
        if flags & 1:
            raise ValueError("encrypted entry " + e.name)
        lsig, _, _, _, _, _, _, _, _, lnlen, lxlen = struct.unpack_from("<IHHHHHIIIHH", data, loff)
        if lsig != 0x04034B50:
            raise ValueError("bad local header for " + e.name)
        start = loff + 30 + lnlen + lxlen
        e.raw = data[start:start + csize]
        entries.append(e)
        p += 46 + nlen + xlen + cmlen
    return entries


def inflate(e):
    if e.method == 0:
        out = e.raw
    elif e.method == 8:
        out = zlib.decompress(e.raw, -15)
    else:
        raise ValueError("unsupported compression %d in %s" % (e.method, e.name))
    if len(out) != e.usize or (zlib.crc32(out) & 0xFFFFFFFF) != e.crc:
        raise ValueError("CRC/size mismatch in " + e.name)
    return out


def stored_entry(name, content, like):
    e = deflated_entry(name, content, like)
    e.raw, e.method, e.csize = content, 0, len(content)
    return e


def deflated_entry(name, content, like):
    e = Entry()
    e.name = name
    e.name_bytes = name.encode("utf-8")
    e.flags = 0x800 if any(ord(c) > 127 for c in name) else 0
    co = zlib.compressobj(9, zlib.DEFLATED, -15)
    e.raw = co.compress(content) + co.flush()
    e.method = 8
    e.crc = zlib.crc32(content) & 0xFFFFFFFF
    e.csize, e.usize = len(e.raw), len(content)
    e.mtime, e.mdate = like.mtime, like.mdate
    e.eattr, e.made_by = 0, 20
    return e


def is_sig_file(name):
    if not name.upper().startswith("META-INF/") or name.count("/") != 1:
        return False
    base = name[9:].upper()
    return (base == "MANIFEST.MF" or base.startswith("SIG-")
            or base.endswith((".SF", ".RSA", ".DSA", ".EC")))


# ---------------------------------------------------------------- zip writing
def write_zip(entries):
    out = bytearray()
    cd = bytearray()
    for e in entries:
        off = len(out)
        flags = e.flags & ~0x0008  # sizes go into the local header, no data descriptor
        need = 20 if e.method == 8 else 10
        extra = b""
        if e.method == 0:
            align = 4096 if e.name.endswith(".so") else 4
            base = off + 30 + len(e.name_bytes)
            pad = (-(base + 6)) % align
            extra = struct.pack("<HHH", 0xD935, 2 + pad, align) + b"\0" * pad  # Android alignment extra field
        out += struct.pack("<IHHHHHIIIHH", 0x04034B50, need, flags, e.method, e.mtime, e.mdate,
                           e.crc, e.csize, e.usize, len(e.name_bytes), len(extra))
        out += e.name_bytes + extra
        out += e.raw
        cd += struct.pack("<IHHHHHHIIIHHHHHII", 0x02014B50, e.made_by, need, flags, e.method, e.mtime,
                          e.mdate, e.crc, e.csize, e.usize, len(e.name_bytes), 0, 0, 0, 0, e.eattr, off)
        cd += e.name_bytes
    cd_off = len(out)
    eocd = struct.pack("<IHHHHIIH", 0x06054B50, 0, 0, len(entries), len(entries), len(cd), cd_off, 0)
    return bytes(out), bytes(cd), eocd


# ---------------------------------------------------------------- manifest patch
def patch_manifest(man, target):
    pool, res_ids, els = axml.parse(man)
    sdk = [el for el in els if el.name == "uses-sdk"]
    if len(sdk) != 1:
        raise ValueError("expected exactly one <uses-sdk>, found %d" % len(sdk))
    a = axml.get_attr(pool, sdk[0], ATTR_TARGET_SDK)
    if a is None:
        raise ValueError("no targetSdkVersion attribute (would need insertion)")
    if a.vtype != axml.TYPE_INT_DEC or a.vsize != 8:
        raise ValueError("targetSdkVersion is not a plain int (type 0x%x)" % a.vtype)
    old = a.vdata
    buf = bytearray(man)
    # Res_value.data is the last u32 of the 20-byte ResXMLTree_attribute
    struct.pack_into("<I", buf, a.offset + 16, target)
    if a.raw is not None:
        raise ValueError("targetSdkVersion has a raw string value; refusing to patch blindly")
    # re-parse to prove the edit landed where intended
    pool2, _, els2 = axml.parse(bytes(buf))
    sdk2 = [el for el in els2 if el.name == "uses-sdk"][0]
    assert axml.get_attr(pool2, sdk2, ATTR_TARGET_SDK).vdata == target
    return bytes(buf), old


# ---------------------------------------------------------------- crypto helpers (OpenSSL)
def openssl(*args, data=None):
    r = subprocess.run([OPENSSL, *args], input=data, capture_output=True)
    if r.returncode != 0:
        raise RuntimeError("openssl %s failed: %s" % (args[0], r.stderr.decode(errors="replace")))
    return r.stdout


def ensure_key(keydir):
    os.makedirs(keydir, exist_ok=True)
    key = os.path.join(keydir, "key.pem")
    cert = os.path.join(keydir, "cert.pem")
    if not os.path.exists(key):
        openssl("genpkey", "-algorithm", "RSA", "-pkeyopt", "rsa_keygen_bits:2048", "-out", key)
    if not os.path.exists(cert):
        openssl("req", "-new", "-x509", "-key", key, "-out", cert, "-days", "10950", "-sha256",
                "-subj", "/CN=Angry Birds Android15 patch/O=Local re-sign")
    cert_der = openssl("x509", "-in", cert, "-outform", "DER")
    pub_der = openssl("pkey", "-in", key, "-pubout", "-outform", "DER")
    return key, cert, cert_der, pub_der


# ---------------------------------------------------------------- v1 (JAR) signature
def mf_line(text):
    b = text.encode("utf-8")
    lines = [b[:72]]
    b = b[72:]
    while b:
        lines.append(b" " + b[:71])
        b = b[71:]
    return b"".join(l + b"\r\n" for l in lines)


def b64(d):
    return base64.b64encode(d).decode()


def v1_sign(entries_with_content, key, cert):
    main = mf_line("Manifest-Version: 1.0") + mf_line("Created-By: 1.0 (Android)") + b"\r\n"
    sections = []
    for name, content in entries_with_content:
        sec = mf_line("Name: " + name) + mf_line("SHA-256-Digest: " + b64(hashlib.sha256(content).digest())) + b"\r\n"
        sections.append((name, sec))
    mf = main + b"".join(s for _, s in sections)
    sf = (mf_line("Signature-Version: 1.0") + mf_line("Created-By: 1.0 (Android)")
          + mf_line("SHA-256-Digest-Manifest: " + b64(hashlib.sha256(mf).digest()))
          + mf_line("SHA-256-Digest-Manifest-Main-Attributes: " + b64(hashlib.sha256(main).digest()))
          + mf_line("X-Android-APK-Signed: 2") + b"\r\n")
    for name, sec in sections:
        sf += mf_line("Name: " + name) + mf_line("SHA-256-Digest: " + b64(hashlib.sha256(sec).digest())) + b"\r\n"
    with tempfile.TemporaryDirectory() as td:
        sfp = os.path.join(td, "CERT.SF")
        with open(sfp, "wb") as f:
            f.write(sf)
        rsa = openssl("cms", "-sign", "-binary", "-noattr", "-nosmimecap", "-md", "sha256", "-outform", "DER",
                      "-signer", cert, "-inkey", key, "-in", sfp)
    return mf, sf, rsa


# ---------------------------------------------------------------- v2 signature
def lp(b):
    return struct.pack("<I", len(b)) + b


def chunked_digest(sections):
    chunks = []
    for sec in sections:
        for i in range(0, len(sec), 1 << 20):
            c = sec[i:i + (1 << 20)]
            chunks.append(hashlib.sha256(b"\xa5" + struct.pack("<I", len(c)) + c).digest())
    return hashlib.sha256(b"\x5a" + struct.pack("<I", len(chunks)) + b"".join(chunks)).digest()


def v2_block(body, cd, eocd, key, cert_der, pub_der):
    ALG = 0x0103  # RSASSA-PKCS1-v1_5 with SHA2-256
    digest = chunked_digest([body, cd, eocd])
    signed_data = (lp(lp(struct.pack("<I", ALG) + lp(digest)))
                   + lp(lp(cert_der))
                   + lp(b""))
    sig = openssl("dgst", "-sha256", "-sign", key, data=signed_data)
    signer = lp(signed_data) + lp(lp(struct.pack("<I", ALG) + lp(sig))) + lp(pub_der)
    value = lp(lp(signer))
    pair = struct.pack("<Q", 4 + len(value)) + struct.pack("<I", 0x7109871A) + value
    size = len(pair) + 8 + 16
    return struct.pack("<Q", size) + pair + struct.pack("<Q", size) + b"APK Sig Block 42"


# ---------------------------------------------------------------- main
def patch(inp, outp, keydir, target=24, dex_fixes=True):
    dex_report = {}
    data = open(inp, "rb").read()
    entries = read_zip(data)
    names = [e.name for e in entries]
    dups = {n for n in names if names.count(n) > 1}
    if dups:
        raise ValueError("duplicate zip entries: %s" % sorted(dups)[:5])
    key, cert, cert_der, pub_der = ensure_key(keydir)

    kept = []
    content = {}
    man_entry = None
    for e in entries:
        if is_sig_file(e.name):
            continue
        c = inflate(e)  # also verifies CRC of the original
        if e.name == "AndroidManifest.xml":
            new_man, old = patch_manifest(c, target)
            man_entry = deflated_entry(e.name, new_man, e)
            man_entry.eattr, man_entry.made_by = e.eattr, e.made_by
            kept.append(man_entry)
            content[e.name] = new_man
        elif re.fullmatch(r"classes\d*\.dex", e.name) and dex_fixes:
            new_dex, res = fixes.patch_dex(c)
            dex_report[e.name] = res
            if new_dex != c:
                ne = deflated_entry(e.name, new_dex, e) if e.method == 8 else stored_entry(e.name, new_dex, e)
                ne.eattr, ne.made_by = e.eattr, e.made_by
                kept.append(ne)
                content[e.name] = new_dex
            else:
                kept.append(e)
                content[e.name] = c
        else:
            kept.append(e)
            content[e.name] = c
    if man_entry is None:
        raise ValueError("no AndroidManifest.xml")

    signed = [(e.name, content[e.name]) for e in kept if not e.name.endswith("/")]
    mf, sf, rsa = v1_sign(signed, key, cert)
    meta = [deflated_entry("META-INF/MANIFEST.MF", mf, man_entry),
            deflated_entry("META-INF/CERT.SF", sf, man_entry),
            deflated_entry("META-INF/CERT.RSA", rsa, man_entry)]
    body, cd, eocd = write_zip(meta + kept)
    block = v2_block(body, cd, eocd, key, cert_der, pub_der)
    new_eocd = eocd[:16] + struct.pack("<I", len(body) + len(block)) + eocd[20:]
    with open(outp, "wb") as f:
        f.write(body + block + cd + new_eocd)
    return old, dex_report


if __name__ == "__main__":
    args = sys.argv[1:]
    target = 24
    if "--target" in args:
        i = args.index("--target")
        target = int(args[i + 1])
        del args[i:i + 2]
    no_dex = "--no-dex-fixes" in args
    if no_dex:
        args.remove("--no-dex-fixes")
    old, rep = patch(args[0], args[1], args[2], target, dex_fixes=not no_dex)
    print("OK targetSdk %d -> %d : %s" % (old, target, os.path.basename(args[1])))
    for dn, res in rep.items():
        for k, v in res.items():
            print("   %s: %s -> %s" % (dn, k, v))
