import sys, zipfile, collections, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import axml

path = sys.argv[1]
full = len(sys.argv) > 2 and sys.argv[2] == "full"
z = zipfile.ZipFile(path)
man = z.read("AndroidManifest.xml")
pool, res_ids, els = axml.parse(man)
print("==", os.path.basename(path))
for el in els:
    if el.name == "manifest":
        print("package:", {a.name: axml.attr_value(pool, a) for a in el.attrs})
    if el.name == "uses-sdk":
        print("uses-sdk:", {a.name: (axml.attr_value(pool, a), "type=0x%02x" % a.vtype) for a in el.attrs})
if not any(e.name == "uses-sdk" for e in els):
    print("uses-sdk: MISSING")
abis = collections.Counter()
for i in z.infolist():
    if i.filename.startswith("lib/"):
        abis[i.filename.split("/")[1]] += 1
print("lib ABIs:", dict(abis))
print("META-INF:", [i.filename for i in z.infolist() if i.filename.startswith("META-INF/") and i.filename.split("/")[-1].split(".")[-1].upper() in ("SF", "RSA", "DSA", "EC", "MF")])
print("entries:", len(z.infolist()), "dex:", [i.filename for i in z.infolist() if i.filename.endswith(".dex") and "/" not in i.filename])
if full:
    print(axml.dump(man))
