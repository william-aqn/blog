"""Minimal Android binary XML (AXML) parser for inspecting / patching AndroidManifest.xml."""
import struct

RES_STRING_POOL_TYPE = 0x0001
RES_XML_TYPE = 0x0003
RES_XML_START_ELEMENT_TYPE = 0x0102
RES_XML_END_ELEMENT_TYPE = 0x0103
RES_XML_RESOURCE_MAP_TYPE = 0x0180

TYPE_REFERENCE = 0x01
TYPE_STRING = 0x03
TYPE_INT_DEC = 0x10
TYPE_INT_HEX = 0x11
TYPE_INT_BOOLEAN = 0x12

# android: attribute resource IDs, used when an obfuscated manifest strips attribute names
ATTR_IDS = {
    0x0101020c: "minSdkVersion",
    0x01010270: "targetSdkVersion",
    0x01010271: "maxSdkVersion",
    0x01010003: "name",
    0x0101021b: "versionCode",
    0x0101021c: "versionName",
}


def _u16(b, o):
    return struct.unpack_from("<H", b, o)[0]


def _u32(b, o):
    return struct.unpack_from("<I", b, o)[0]


class StringPool:
    def __init__(self, data, off):
        self.off = off
        (self.type, self.header_size, self.size, self.string_count, self.style_count,
         self.flags, self.strings_start, self.styles_start) = struct.unpack_from("<HHIIIIII", data, off)
        self.utf8 = bool(self.flags & (1 << 8))
        offs_base = off + self.header_size
        self.strings = []
        for i in range(self.string_count):
            so = _u32(data, offs_base + i * 4)
            p = off + self.strings_start + so
            self.strings.append(self._read(data, p))

    def _read(self, data, p):
        if self.utf8:
            # utf16 length then utf8 length, each 1 or 2 bytes
            n = data[p]
            p += 2 if n & 0x80 else 1
            n8 = data[p]
            if n8 & 0x80:
                n8 = ((n8 & 0x7F) << 8) | data[p + 1]
                p += 2
            else:
                p += 1
            return data[p:p + n8].decode("utf-8", "replace")
        n = _u16(data, p)
        p += 2
        if n & 0x8000:
            n = ((n & 0x7FFF) << 16) | _u16(data, p)
            p += 2
        return data[p:p + n * 2].decode("utf-16-le", "replace")


class Attr:
    __slots__ = ("offset", "ns", "name", "raw", "vsize", "vres0", "vtype", "vdata", "res_id")


class Element:
    def __init__(self, name, depth, offset):
        self.name = name
        self.depth = depth
        self.offset = offset
        self.attrs = []
        self.parent = None


def parse(data):
    """Return (string_pool, resource_ids, elements_in_order)."""
    data = bytes(data)
    typ, hsize, total = struct.unpack_from("<HHI", data, 0)
    assert typ == RES_XML_TYPE, "not AXML"
    pos = hsize
    pool = None
    res_ids = []
    elements = []
    stack = []
    while pos < total:
        ctype, chsize, csize = struct.unpack_from("<HHI", data, pos)
        if ctype == RES_STRING_POOL_TYPE:
            pool = StringPool(data, pos)
        elif ctype == RES_XML_RESOURCE_MAP_TYPE:
            n = (csize - chsize) // 4
            res_ids = list(struct.unpack_from("<%dI" % n, data, pos + chsize))
        elif ctype == RES_XML_START_ELEMENT_TYPE:
            ext = pos + chsize
            ns_idx, name_idx, attr_start, attr_size, attr_count = struct.unpack_from("<iiHHH", data, ext)
            el = Element(pool.strings[name_idx], len(stack), pos)
            el.parent = stack[-1] if stack else None
            for i in range(attr_count):
                ao = ext + attr_start + i * attr_size
                a = Attr()
                a.offset = ao
                ans, aname, araw, vsize, vres0, vtype, vdata = struct.unpack_from("<iiiHBBI", data, ao)
                a.ns = pool.strings[ans] if ans >= 0 else None
                a.res_id = res_ids[aname] if 0 <= aname < len(res_ids) else None
                a.name = pool.strings[aname] if aname >= 0 else None
                if a.res_id in ATTR_IDS and not a.name:
                    a.name = ATTR_IDS[a.res_id]
                a.raw = pool.strings[araw] if araw >= 0 else None
                a.vsize, a.vres0, a.vtype, a.vdata = vsize, vres0, vtype, vdata
                el.attrs.append(a)
            elements.append(el)
            stack.append(el)
        elif ctype == RES_XML_END_ELEMENT_TYPE:
            stack.pop()
        pos += csize
    return pool, res_ids, elements


def attr_value(pool, a):
    if a.vtype == TYPE_STRING:
        return pool.strings[a.vdata]
    if a.vtype == TYPE_INT_BOOLEAN:
        return a.vdata != 0
    if a.vtype in (TYPE_INT_DEC,):
        return struct.unpack("<i", struct.pack("<I", a.vdata))[0]
    if a.vtype == TYPE_INT_HEX:
        return hex(a.vdata)
    if a.vtype == TYPE_REFERENCE:
        return "@0x%08x" % a.vdata
    return "(type 0x%02x) 0x%x" % (a.vtype, a.vdata)


def get_attr(pool, el, res_id):
    for a in el.attrs:
        if a.res_id == res_id:
            return a
    return None


def dump(data):
    pool, res_ids, els = parse(data)
    out = []
    for el in els:
        parts = []
        for a in el.attrs:
            parts.append("%s=%r" % (a.name or ("0x%08x" % (a.res_id or 0)), attr_value(pool, a)))
        out.append("  " * el.depth + "<" + el.name + " " + " ".join(parts) + ">")
    return "\n".join(out)
