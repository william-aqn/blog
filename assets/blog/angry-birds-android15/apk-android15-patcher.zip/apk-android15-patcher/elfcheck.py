"""Check native libs in an APK for things that break when targetSdk >= 23/24:
TEXTREL (rejected for targetSdk>=23), DT_NEEDED on non-public system libs (rejected for targetSdk>=24),
dlopen'd private lib names in strings."""
import sys, zipfile, struct, re

PUBLIC = {
    "libandroid.so", "libc.so", "libdl.so", "libEGL.so", "libGLESv1_CM.so", "libGLESv2.so", "libGLESv3.so",
    "libjnigraphics.so", "liblog.so", "libm.so", "libOpenMAXAL.so", "libOpenSLES.so", "libstdc++.so",
    "libvulkan.so", "libz.so", "libmediandk.so", "libcamera2ndk.so", "libnativewindow.so", "libsync.so",
    "libaaudio.so", "libneuralnetworks.so", "libbinder_ndk.so", "libicu.so", "libamidi.so",
}
# libs that were on the temporary greylist for targetSdk<24 only
GREYLIST = {"libandroid_runtime.so", "libcutils.so", "libcrypto.so", "libexpat.so", "libgui.so", "libmedia.so",
            "libnativehelper.so", "libssl.so", "libstagefright.so", "libsqlite.so", "libui.so", "libutils.so",
            "libvorbisidec.so", "libbinder.so", "libskia.so", "libmedia_jni.so", "libicuuc.so", "libicui18n.so"}

DT_NEEDED, DT_TEXTREL, DT_FLAGS, DT_SONAME = 1, 22, 30, 14
DF_TEXTREL = 0x4


def analyze(name, b):
    if b[:4] != b"\x7fELF":
        return {"lib": name, "error": "not ELF"}
    is64 = b[4] == 2
    le = b[5] == 1
    E = "<" if le else ">"
    if is64:
        e_phoff, e_shoff = struct.unpack_from(E + "QQ", b, 0x20)
        e_phentsize, e_phnum, e_shentsize, e_shnum, e_shstrndx = struct.unpack_from(E + "HHHHH", b, 0x36)
    else:
        e_phoff, e_shoff = struct.unpack_from(E + "II", b, 0x1C)
        e_phentsize, e_phnum, e_shentsize, e_shnum, e_shstrndx = struct.unpack_from(E + "HHHHH", b, 0x2A)
    loads, dyn = [], None
    for i in range(e_phnum):
        o = e_phoff + i * e_phentsize
        if is64:
            p_type, p_flags, p_offset, p_vaddr, p_paddr, p_filesz, p_memsz, p_align = struct.unpack_from(E + "IIQQQQQQ", b, o)
        else:
            p_type, p_offset, p_vaddr, p_paddr, p_filesz, p_memsz, p_flags, p_align = struct.unpack_from(E + "IIIIIIII", b, o)
        if p_type == 1:
            loads.append((p_vaddr, p_offset, p_filesz, p_align, p_flags))
        if p_type == 2:
            dyn = (p_offset, p_filesz)

    def v2o(v):
        for va, off, fs, al, fl in loads:
            if va <= v < va + fs:
                return v - va + off
        return None

    entries = []
    if dyn:
        sz = 16 if is64 else 8
        for i in range(dyn[1] // sz):
            if is64:
                tag, val = struct.unpack_from(E + "qQ", b, dyn[0] + i * sz)
            else:
                tag, val = struct.unpack_from(E + "iI", b, dyn[0] + i * sz)
            if tag == 0:
                break
            entries.append((tag, val))
    strtab = next((v for t, v in entries if t == 5), None)
    stro = v2o(strtab) if strtab is not None else None

    def s(off):
        p = stro + off
        return b[p:b.index(b"\0", p)].decode("latin1")

    needed = [s(v) for t, v in entries if t == DT_NEEDED]
    soname = next((s(v) for t, v in entries if t == DT_SONAME), None)
    textrel = any(t == DT_TEXTREL for t, v in entries) or any(t == DT_FLAGS and v & DF_TEXTREL for t, v in entries)
    # dlopen'ed library names referenced as strings
    strs = set(m.decode() for m in re.findall(rb"lib[A-Za-z0-9_+\-.]+\.so", b))
    private_strs = sorted(x for x in strs if x not in PUBLIC and x in GREYLIST)
    return {
        "lib": name, "elf": "64" if is64 else "32", "soname": soname, "needed": needed,
        "TEXTREL": textrel,
        "needed_nonpublic": [n for n in needed if n not in PUBLIC],
        "greylist_strings": private_strs,
        "shdr_ok": e_shoff != 0 and e_shnum > 0,
        "load_align": sorted(set(hex(l[3]) for l in loads)),
    }


if __name__ == "__main__":
    for path in sys.argv[1:]:
        z = zipfile.ZipFile(path)
        print("==", path.split("\\")[-1])
        libs = [i.filename for i in z.infolist() if i.filename.startswith("lib/") and i.filename.endswith(".so")]
        for l in libs:
            print("  ", analyze(l, z.read(l)))
