"""Small Dalvik disassembler (stdlib only).

Usage: python -I dexdis.py <apk> <out.txt>
Writes a smali-like listing of every method with resolved references, try/catch ranges and
string constants, so it can be grepped.
"""
import sys, struct, zipfile

FMT = {}
def _set(rng, fmt):
    for op in rng:
        FMT[op] = fmt

_set(range(0x00, 0x100), "10x")
FMT.update({0x01: "12x", 0x02: "22x", 0x03: "32x", 0x04: "12x", 0x05: "22x", 0x06: "32x", 0x07: "12x",
            0x08: "22x", 0x09: "32x", 0x0a: "11x", 0x0b: "11x", 0x0c: "11x", 0x0d: "11x", 0x0e: "10x",
            0x0f: "11x", 0x10: "11x", 0x11: "11x", 0x12: "11n", 0x13: "21s", 0x14: "31i", 0x15: "21h",
            0x16: "21s", 0x17: "31i", 0x18: "51l", 0x19: "21h", 0x1a: "21c", 0x1b: "31c", 0x1c: "21c",
            0x1d: "11x", 0x1e: "11x", 0x1f: "21c", 0x20: "22c", 0x21: "12x", 0x22: "21c", 0x23: "22c",
            0x24: "35c", 0x25: "3rc", 0x26: "31t", 0x27: "11x", 0x28: "10t", 0x29: "20t", 0x2a: "30t",
            0x2b: "31t", 0x2c: "31t", 0xfa: "45cc", 0xfb: "4rcc", 0xfc: "35c", 0xfd: "3rc", 0xfe: "21c",
            0xff: "21c"})
_set(range(0x2d, 0x32), "23x")
_set(range(0x32, 0x38), "22t")
_set(range(0x38, 0x3e), "21t")
_set(range(0x44, 0x52), "23x")
_set(range(0x52, 0x60), "22c")
_set(range(0x60, 0x6e), "21c")
_set(range(0x6e, 0x73), "35c")
_set(range(0x74, 0x79), "3rc")
_set(range(0x7b, 0x90), "12x")
_set(range(0x90, 0xb0), "23x")
_set(range(0xb0, 0xd0), "12x")
_set(range(0xd0, 0xd8), "22s")
_set(range(0xd8, 0xe3), "22b")
SIZE = {"10x": 1, "12x": 1, "11n": 1, "11x": 1, "10t": 1, "20t": 2, "22x": 2, "21t": 2, "21s": 2, "21h": 2,
        "21c": 2, "23x": 2, "22b": 2, "22t": 2, "22s": 2, "22c": 2, "30t": 3, "32x": 3, "31i": 3, "31t": 3,
        "31c": 3, "35c": 3, "3rc": 3, "45cc": 4, "4rcc": 4, "51l": 5}

NAMES = {0x00: "nop", 0x01: "move", 0x02: "move/from16", 0x03: "move/16", 0x04: "move-wide",
         0x05: "move-wide/from16", 0x06: "move-wide/16", 0x07: "move-object", 0x08: "move-object/from16",
         0x09: "move-object/16", 0x0a: "move-result", 0x0b: "move-result-wide", 0x0c: "move-result-object",
         0x0d: "move-exception", 0x0e: "return-void", 0x0f: "return", 0x10: "return-wide", 0x11: "return-object",
         0x12: "const/4", 0x13: "const/16", 0x14: "const", 0x15: "const/high16", 0x16: "const-wide/16",
         0x17: "const-wide/32", 0x18: "const-wide", 0x19: "const-wide/high16", 0x1a: "const-string",
         0x1b: "const-string/jumbo", 0x1c: "const-class", 0x1d: "monitor-enter", 0x1e: "monitor-exit",
         0x1f: "check-cast", 0x20: "instance-of", 0x21: "array-length", 0x22: "new-instance", 0x23: "new-array",
         0x24: "filled-new-array", 0x25: "filled-new-array/range", 0x26: "fill-array-data", 0x27: "throw",
         0x28: "goto", 0x29: "goto/16", 0x2a: "goto/32", 0x2b: "packed-switch", 0x2c: "sparse-switch",
         0x2d: "cmpl-float", 0x2e: "cmpg-float", 0x2f: "cmpl-double", 0x30: "cmpg-double", 0x31: "cmp-long",
         0x32: "if-eq", 0x33: "if-ne", 0x34: "if-lt", 0x35: "if-ge", 0x36: "if-gt", 0x37: "if-le",
         0x38: "if-eqz", 0x39: "if-nez", 0x3a: "if-ltz", 0x3b: "if-gez", 0x3c: "if-gtz", 0x3d: "if-lez",
         0x6e: "invoke-virtual", 0x6f: "invoke-super", 0x70: "invoke-direct", 0x71: "invoke-static",
         0x72: "invoke-interface", 0x74: "invoke-virtual/range", 0x75: "invoke-super/range",
         0x76: "invoke-direct/range", 0x77: "invoke-static/range", 0x78: "invoke-interface/range",
         0xfa: "invoke-polymorphic", 0xfb: "invoke-polymorphic/range", 0xfc: "invoke-custom",
         0xfd: "invoke-custom/range", 0xfe: "const-method-handle", 0xff: "const-method-type"}
for i, n in enumerate(["aget", "aget-wide", "aget-object", "aget-boolean", "aget-byte", "aget-char", "aget-short",
                       "aput", "aput-wide", "aput-object", "aput-boolean", "aput-byte", "aput-char", "aput-short"]):
    NAMES[0x44 + i] = n
for i, n in enumerate(["iget", "iget-wide", "iget-object", "iget-boolean", "iget-byte", "iget-char", "iget-short",
                       "iput", "iput-wide", "iput-object", "iput-boolean", "iput-byte", "iput-char", "iput-short"]):
    NAMES[0x52 + i] = n
    NAMES[0x60 + i] = "s" + n[1:]
for op in range(0x7b, 0xe3):
    NAMES.setdefault(op, "op_%02x" % op)


def uleb(b, p):
    r = s = 0
    while True:
        x = b[p]; p += 1
        r |= (x & 0x7F) << s
        s += 7
        if not x & 0x80:
            return r, p


def sleb(b, p):
    r = s = 0
    while True:
        x = b[p]; p += 1
        r |= (x & 0x7F) << s
        s += 7
        if not x & 0x80:
            if x & 0x40:
                r -= 1 << s
            return r, p


class Dex:
    def __init__(self, b):
        self.b = b
        h = struct.unpack_from("<8s I 20s I I I I I I I I I I I I I I I I I I I I", b, 0)
        (_, _, _, self.file_size, _, _, _, _, _, self.str_n, self.str_off, self.type_n, self.type_off,
         self.proto_n, self.proto_off, self.field_n, self.field_off, self.meth_n, self.meth_off,
         self.cls_n, self.cls_off, _, _) = h
        self._str = {}

    def s(self, i):
        if i in self._str:
            return self._str[i]
        off = struct.unpack_from("<I", self.b, self.str_off + i * 4)[0]
        _, p = uleb(self.b, off)
        e = self.b.index(b"\0", p)
        v = self.b[p:e].decode("utf-8", "replace")  # MUTF-8 close enough for grepping
        self._str[i] = v
        return v

    def t(self, i):
        return self.s(struct.unpack_from("<I", self.b, self.type_off + i * 4)[0])

    def proto(self, i):
        shorty, ret, params = struct.unpack_from("<III", self.b, self.proto_off + i * 12)
        ps = []
        if params:
            n = struct.unpack_from("<I", self.b, params)[0]
            ps = [self.t(struct.unpack_from("<H", self.b, params + 4 + k * 2)[0]) for k in range(n)]
        return "(" + "".join(ps) + ")" + self.t(ret)

    def field(self, i):
        c, ty, n = struct.unpack_from("<HHI", self.b, self.field_off + i * 8)
        return "%s->%s:%s" % (self.t(c), self.s(n), self.t(ty))

    def method(self, i):
        c, pr, n = struct.unpack_from("<HHI", self.b, self.meth_off + i * 8)
        return "%s->%s%s" % (self.t(c), self.s(n), self.proto(pr))

    def classes(self):
        for k in range(self.cls_n):
            (cidx, flags, sup, ifaces, src, ann, data, sv) = struct.unpack_from("<8I", self.b, self.cls_off + k * 32)
            yield cidx, sup, data

    def methods_of(self, data):
        if not data:
            return
        b = self.b
        p = data
        sf, p = uleb(b, p); inf, p = uleb(b, p); dm, p = uleb(b, p); vm, p = uleb(b, p)
        for _ in range(sf + inf):
            _, p = uleb(b, p); _, p = uleb(b, p)
        for cnt in (dm, vm):
            idx = 0
            for _ in range(cnt):
                d, p = uleb(b, p); idx += d
                acc, p = uleb(b, p)
                code, p = uleb(b, p)
                yield idx, acc, code

    def code(self, off):
        b = self.b
        regs, ins, outs, tries, dbg, n = struct.unpack_from("<HHHHII", b, off)
        insns = off + 16
        try_list = []
        if tries:
            tp = insns + n * 2
            if n % 2:
                tp += 2
            hb = tp + tries * 8
            for k in range(tries):
                st, cnt, hoff = struct.unpack_from("<IHH", b, tp + k * 8)
                hp = hb + hoff
                sz, hp = sleb(b, hp)
                catches = []
                for _ in range(abs(sz)):
                    ti, hp = uleb(b, hp); addr, hp = uleb(b, hp)
                    catches.append((self.t(ti), addr))
                if sz <= 0:
                    addr, hp = uleb(b, hp)
                    catches.append(("<any>", addr))
                try_list.append((st, st + cnt, catches))
        return regs, ins, insns, n, try_list


def disasm(dex, insns, n):
    b = dex.b
    pc = 0
    out = []
    while pc < n:
        w = struct.unpack_from("<H", b, insns + pc * 2)[0]
        op = w & 0xFF
        if op == 0 and w in (0x0100, 0x0200, 0x0300):
            if w == 0x0100:
                sz = struct.unpack_from("<H", b, insns + pc * 2 + 2)[0]
                pc += sz * 2 + 4
            elif w == 0x0200:
                sz = struct.unpack_from("<H", b, insns + pc * 2 + 2)[0]
                pc += sz * 4 + 2
            else:
                ew, sz = struct.unpack_from("<HI", b, insns + pc * 2 + 2)
                pc += 4 + (sz * ew + 1) // 2
            continue
        fmt = FMT[op]
        u = lambda k: struct.unpack_from("<H", b, insns + (pc + k) * 2)[0]
        hi = w >> 8
        name = NAMES.get(op, "op_%02x" % op)
        txt = name
        if fmt == "11n":
            lit = hi >> 4
            if lit & 8:
                lit -= 16
            txt = "%s v%d, %d" % (name, hi & 0xF, lit)
        elif fmt == "11x":
            txt = "%s v%d" % (name, hi)
        elif fmt == "12x":
            txt = "%s v%d, v%d" % (name, hi & 0xF, hi >> 4)
        elif fmt == "21s":
            v = u(1)
            if v & 0x8000:
                v -= 0x10000
            txt = "%s v%d, %d" % (name, hi, v)
        elif fmt == "21h":
            txt = "%s v%d, 0x%x" % (name, hi, u(1))
        elif fmt == "31i":
            v = u(1) | (u(2) << 16)
            if v & 0x80000000:
                v -= 1 << 32
            txt = "%s v%d, %d" % (name, hi, v)
        elif fmt in ("21c", "31c"):
            idx = u(1) if fmt == "21c" else (u(1) | (u(2) << 16))
            if op in (0x1a, 0x1b):
                ref = repr(dex.s(idx))
            elif op in (0x1c, 0x1f, 0x22):
                ref = dex.t(idx)
            elif 0x60 <= op <= 0x6d:
                ref = dex.field(idx)
            else:
                ref = "#%d" % idx
            txt = "%s v%d, %s" % (name, hi, ref)
        elif fmt == "22c":
            idx = u(1)
            ref = dex.t(idx) if op in (0x20, 0x23) else dex.field(idx)
            txt = "%s v%d, v%d, %s" % (name, hi & 0xF, hi >> 4, ref)
        elif fmt == "35c":
            cnt = hi >> 4
            g = hi & 0xF
            idx = u(1)
            r = u(2)
            regs = [r & 0xF, (r >> 4) & 0xF, (r >> 8) & 0xF, r >> 12, g][:cnt]
            ref = dex.method(idx) if op != 0x24 and op != 0xfc else ("#%d" % idx if op == 0xfc else dex.t(idx))
            txt = "%s {%s}, %s" % (name, ", ".join("v%d" % x for x in regs), ref)
        elif fmt == "3rc":
            idx = u(1)
            c = u(2)
            ref = dex.method(idx) if op not in (0x25, 0xfd) else ("#%d" % idx if op == 0xfd else dex.t(idx))
            txt = "%s {v%d .. v%d}, %s" % (name, c, c + hi - 1, ref)
        elif fmt in ("21t", "22t", "10t", "20t", "30t", "31t"):
            if fmt == "10t":
                off = hi - 256 if hi & 0x80 else hi
                txt = "%s :%04x" % (name, pc + off)
            elif fmt == "20t":
                off = u(1); off = off - 0x10000 if off & 0x8000 else off
                txt = "%s :%04x" % (name, pc + off)
            elif fmt == "30t" or fmt == "31t":
                off = u(1) | (u(2) << 16); off = off - (1 << 32) if off & 0x80000000 else off
                txt = "%s v%d, :%04x" % (name, hi, pc + off) if fmt == "31t" else "%s :%04x" % (name, pc + off)
            elif fmt == "21t":
                off = u(1); off = off - 0x10000 if off & 0x8000 else off
                txt = "%s v%d, :%04x" % (name, hi, pc + off)
            else:
                off = u(1); off = off - 0x10000 if off & 0x8000 else off
                txt = "%s v%d, v%d, :%04x" % (name, hi & 0xF, hi >> 4, pc + off)
        elif fmt == "22s":
            v = u(1); v = v - 0x10000 if v & 0x8000 else v
            txt = "%s v%d, v%d, %d" % (name, hi & 0xF, hi >> 4, v)
        elif fmt == "22b":
            x = u(1)
            lit = x >> 8
            lit = lit - 256 if lit & 0x80 else lit
            txt = "%s v%d, v%d, %d" % (name, hi, x & 0xFF, lit)
        elif fmt == "22x":
            txt = "%s v%d, v%d" % (name, hi, u(1))
        elif fmt == "23x":
            x = u(1)
            txt = "%s v%d, v%d, v%d" % (name, hi, x & 0xFF, x >> 8)
        elif fmt == "32x":
            txt = "%s v%d, v%d" % (name, u(1), u(2))
        elif fmt == "51l":
            txt = "%s v%d, <wide>" % (name, hi)
        out.append((pc, txt))
        pc += SIZE[fmt]
    return out


ACC = {0x1: "public", 0x2: "private", 0x4: "protected", 0x8: "static", 0x10: "final", 0x20: "synchronized",
       0x100: "native", 0x400: "abstract", 0x10000: "constructor"}


def main(apk, outp):
    z = zipfile.ZipFile(apk)
    dexes = sorted(n for n in z.namelist() if n.startswith("classes") and n.endswith(".dex") and "/" not in n)
    with open(outp, "w", encoding="utf-8") as f:
        for dn in dexes:
            dex = Dex(z.read(dn))
            for cidx, sup, data in dex.classes():
                cname = dex.t(cidx)
                f.write("\n.class %s  # super %s  [%s]\n" % (cname, dex.t(sup) if sup != 0xFFFFFFFF else "-", dn))
                for midx, acc, code in dex.methods_of(data):
                    flags = " ".join(v for k, v in ACC.items() if acc & k)
                    f.write("  .method %s %s\n" % (flags, dex.method(midx)))
                    if not code:
                        continue
                    regs, ins, insns, n, tries = dex.code(code)
                    f.write("    .registers %d (params start v%d)\n" % (regs, regs - ins))
                    for st, en, catches in tries:
                        f.write("    .try :%04x-:%04x catch %s\n" % (
                            st, en, ", ".join("%s->:%04x" % c for c in catches)))
                    for pc, txt in disasm(dex, insns, n):
                        f.write("    :%04x %s\n" % (pc, txt))
                    f.write("  .end method\n")


if __name__ == "__main__":
    main(sys.argv[1], sys.argv[2])
