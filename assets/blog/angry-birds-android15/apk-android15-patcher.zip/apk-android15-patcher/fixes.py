"""Same-size bytecode fixes for code that breaks when targetSdkVersion is raised to 24
(or when the APK is re-signed).

Every recipe checks the exact current instructions before touching anything (so nothing is
patched unless the code is what was analysed), writes a same-size replacement, re-disassembles
the method, compares it with the expected listing and checks that every try boundary / handler /
branch target still falls on an instruction start.
"""
import os, re, struct, sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from dexdis import Dex, disasm
from dexpatch import DexPatcher

INTENT_INIT = "Landroid/content/Intent;-><init>(Ljava/lang/String;)V"
SET_PACKAGE = "Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;"
IAB_BIND = "'com.android.vending.billing.InAppBillingService.BIND'"
AIWU_CERT = "3082035130820239a003020102020445e69799300d06092a864886f70d0101"

NOP = b"\x00\x00"
RETURN_VOID = struct.pack("<H", 0x0E)


def const4(reg, val):
    return struct.pack("<H", 0x12 | (reg << 8) | ((val & 0xF) << 12))


def return_reg(reg):
    return struct.pack("<H", 0x0F | (reg << 8))


def _texts(listing):
    return [t for _, t in listing]


def _check_boundaries(listing, tries):
    starts = {pc for pc, _ in listing}
    last = listing[-1][0]
    for st, en, catches in tries:
        if st not in starts:
            return "try start :%04x not on instruction boundary" % st
        if en <= last and en not in starts:
            return "try end :%04x not on instruction boundary" % en
        for _, h in catches:
            if h not in starts:
                return "handler :%04x not on instruction boundary" % h
    for pc, t in listing:
        if t.split()[0].startswith(("if-", "goto")):
            tgt = int(re.search(r":([0-9a-f]{4})$", t).group(1), 16)
            if tgt not in starts:
                return "branch at :%04x targets non-boundary :%04x" % (pc, tgt)
    return None


class Recipe:
    """name, why, targets(p) -> [method sigs], plan(p, listing) -> ([(pc, bytes)], expected_texts) | 'already'."""

    def __init__(self, name, why, targets, plan):
        self.name, self.why, self.targets, self.plan = name, why, targets, plan


def fixed_targets(*sigs):
    return lambda p: [s for s in sigs if p.method_idx(s) is not None]


# ---------------------------------------------------------------- 1. billing: make the Intent explicit
def plan_billing_set_package(cls):
    bind = "Landroid/app/Activity;->bindService(Landroid/content/Intent;Landroid/content/ServiceConnection;I)Z"
    before = [
        "const-string v0, 'bindToService()'",
        "invoke-static {v0}, %s->log(Ljava/lang/String;)V" % cls,
        "iget-object v0, v3, %s->c:Landroid/app/Activity;" % cls,
        "new-instance v1, Landroid/content/Intent;",
        "const-string v2, " + IAB_BIND,
        "invoke-direct {v1, v2}, " + INTENT_INIT,
        "const/4 v2, 1",
        "invoke-virtual {v0, v1, v3, v2}, " + bind,
        "move-result v0",
        "return v0",
    ]
    after = before[2:6] + ["const-string v2, 'com.android.vending'",
                           "invoke-virtual {v1, v2}, " + SET_PACKAGE] + before[6:]

    def plan(p, listing):
        t = _texts(listing)
        if any("->setPackage(" in x for x in t):
            return "already"  # Rovio shipped this exact fix in its targetSdk-21 builds
        if t != before:
            raise ValueError("unexpected body")
        raw = bytes(p.buf[p.cur_insns + 5 * 2: p.cur_insns + 14 * 2])  # iget-object .. invoke-direct
        blob = raw + p.const_string(2, p.string_idx("com.android.vending")) + \
            p.invoke(0x6E, [1, 2], p.method_idx(SET_PACKAGE))
        return [(0, blob)], after
    return plan


# ---------------------------------------------------------------- 2. billing: no room for setPackage -> report "Play billing unavailable"
def plan_billing_return_false(cls):
    bind = "Landroid/app/Activity;->bindService(Landroid/content/Intent;Landroid/content/ServiceConnection;I)Z"
    before = [
        "iget-object v0, v3, %s->mApp:Landroid/app/Activity;" % cls,
        "new-instance v1, Landroid/content/Intent;",
        "const-string v2, " + IAB_BIND,
        "invoke-direct {v1, v2}, " + INTENT_INIT,
        "const/4 v2, 1",
        "invoke-virtual {v0, v1, v3, v2}, " + bind,
        "move-result v0",
        "return v0",
    ]
    after = ["const/4 v0, 0", "return v0"] + before[1:]

    def plan(p, listing):
        t = _texts(listing)
        if t == after or any("->setPackage(" in x for x in t):
            return "already"
        if t != before:
            raise ValueError("unexpected body")
        return [(0, const4(0, 0) + return_reg(0))], after
    return plan


# ---------------------------------------------------------------- 3. aiwu anti-re-sign kill switches
def aiwu_targets(p):
    out = []
    sidx = p.string_idx(AIWU_CERT)
    if sidx is None:
        return out
    d = p.dex
    for cidx, sup, data in d.classes():
        for midx, acc, code in d.methods_of(data):
            if not code:
                continue
            sig = d.method(midx)
            if not sig.endswith("()V"):
                continue
            regs, ins, insns, n, tries = d.code(code)
            if struct.unpack_from("<HH", d.b, insns) == (0x1A | (2 << 8), sidx):
                out.append(sig)
    return out


def plan_aiwu(p, listing):
    t = _texts(listing)
    if t[0] == "return-void":
        return "already"
    if t[0] != "const-string v2, '%s'" % AIWU_CERT or not any("Process;->killProcess" in x for x in t) \
            or not any("Signature;->toCharsString" in x for x in t):
        raise ValueError("unexpected body")
    return [(0, RETURN_VOID + NOP)], ["return-void", "nop"] + t[1:]


# ---------------------------------------------------------------- 4. Burstly: getDeviceId() -> null
def plan_null_device_id(p, listing):
    t = _texts(listing)
    idx = [i for i, x in enumerate(t) if x.endswith("Landroid/telephony/TelephonyManager;->getDeviceId()Ljava/lang/String;")]
    if not idx:
        if any(x.startswith("const/4") for x in t) and "nop" in t:
            return "already"
        raise ValueError("no getDeviceId call")
    writes, new = [], list(t)
    for i in reversed(idx):
        m = re.fullmatch(r"move-result-object v(\d+)", t[i + 1])
        if not m or not t[i].startswith("invoke-virtual {v"):
            raise ValueError("unexpected getDeviceId pattern")
        reg = int(m.group(1))
        if reg > 15:
            raise ValueError("register too high for const/4")
        pc = listing[i][0]
        assert listing[i + 1][0] == pc + 3
        writes.append((pc, const4(reg, 0) + NOP * 3))
        new[i:i + 2] = ["const/4 v%d, 0" % reg, "nop", "nop", "nop"]
    return writes, new


# ---------------------------------------------------------------- 5. Stella share: don't put a file:// Uri into the chooser
def plan_drop_stream(p, listing):
    t = _texts(listing)
    put = r"invoke-virtual \{v(\d+), v(\d+), v(\d+)\}, Landroid/content/Intent;->putExtra\(Ljava/lang/String;Landroid/os/Parcelable;\)Landroid/content/Intent;"
    fr = [i for i, x in enumerate(t) if x.endswith("Landroid/net/Uri;->fromFile(Ljava/io/File;)Landroid/net/Uri;")]
    if len(fr) != 1:
        raise ValueError("unexpected body")
    uri_reg = re.fullmatch(r"move-result-object v(\d+)", t[fr[0] + 1]).group(1)
    hits = [i for i, x in enumerate(t) if re.fullmatch(put, x)]
    if not hits:
        if t.count("nop") >= 3:
            return "already"
        raise ValueError("unexpected body")
    if len(hits) != 1:
        raise ValueError("unexpected body")
    i = hits[0]
    _, key_reg, val_reg = re.fullmatch(put, t[i]).groups()
    if val_reg != uri_reg or t[i - 1] != "const-string v%s, 'android.intent.extra.STREAM'" % key_reg \
            or t[i + 1].startswith("move-result"):
        raise ValueError("unexpected body")
    new = t[:i] + ["nop", "nop", "nop"] + t[i + 1:]
    return [(listing[i][0], NOP * 3)], new


def all_recipes():
    F = "Lcom/rovio/fusion/payment/google/GooglePlayPaymentProvider;"
    K = "Lcom/rovio/skynest/payment/google/GooglePlayPaymentProvider;"
    return [
        Recipe("billing-explicit-intent",
               "IAB bindService with implicit Intent -> IllegalArgumentException at targetSdk>=21",
               fixed_targets(F + "->a()Z"), plan_billing_set_package(F)),
        Recipe("billing-explicit-intent",
               "IAB bindService with implicit Intent -> IllegalArgumentException at targetSdk>=21",
               fixed_targets(K + "->a()Z"), plan_billing_set_package(K)),
        Recipe("billing-unavailable",
               "IAB bindService with implicit Intent (no room for setPackage) -> report bind failure",
               fixed_targets(F + "->bindToIabService()Z", K + "->bindToIabService()Z"),
               None),  # plan chosen per class below
        Recipe("aiwu-killswitch-off",
               "mod's own-signature check kills the process after re-signing",
               aiwu_targets, plan_aiwu),
        Recipe("burstly-deviceid-null",
               "getDeviceId() throws SecurityException at targetSdk>=23 without READ_PHONE_STATE",
               fixed_targets("Lcom/burstly/lib/util/Utils;->getRawDeviceId(Landroid/content/Context;)Ljava/lang/String;",
                             "Lcom/burstly/lib/util/Utils;->encryptedDeviceId(Landroid/content/Context;)Ljava/lang/String;"),
               plan_null_device_id),
        Recipe("share-no-file-uri",
               "file:// Uri in a chooser -> FileUriExposedException at targetSdk>=24",
               fixed_targets("Lcom/rovio/fusion/Share;->shareFromMediaStoreWithMimeType(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;I)V"),
               plan_drop_stream),
    ]


def _plan_for(recipe, sig):
    if recipe.plan is not None:
        return recipe.plan
    cls = sig.split("->")[0]
    return plan_billing_return_false(cls)


def patch_dex(data, recipes=None):
    p = DexPatcher(data)
    results = {}
    for r in recipes or all_recipes():
        for sig in r.targets(p):
            code, insns, n, tries, regs = p.find_code(sig)
            p.cur_insns = insns
            cur = disasm(Dex(bytes(p.buf)), insns, n)
            res = _plan_for(r, sig)(p, cur)
            key = "%s %s" % (r.name, sig)
            if res == "already":
                results[key] = "already-ok"
                continue
            writes, expected = res
            for pc, blob in writes:
                p.write(insns, pc, blob)
            new = disasm(Dex(bytes(p.buf)), insns, n)
            if _texts(new) != expected:
                raise AssertionError("%s: patched listing unexpected:\n  %s" % (sig, "\n  ".join(_texts(new))))
            if len(new) and new[-1][0] >= n:
                raise AssertionError(sig + ": listing overruns method")
            err = _check_boundaries(new, tries)
            if err:
                raise AssertionError(sig + ": " + err)
            results[key] = "applied"
    changed = any(v == "applied" for v in results.values())
    return (p.finish() if changed else data), results
