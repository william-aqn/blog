# apk-android15-patcher

Поднимает `targetSdkVersion` старых APK до 24, чтобы Android 14/15 разрешил установку
(`INSTALL_FAILED_DEPRECATED_SDK_VERSION`), чинит в байткоде то, что от этого ломается
в играх Rovio, и заново подписывает APK (v1 + v2).

Нужны только **Python 3** и **OpenSSL**: из PATH, из переменной `OPENSSL` или из Git for Windows
(`C:\Program Files\Git\mingw64\bin\openssl.exe`). Java, apktool и Android SDK не нужны.

## Запуск

Вся папка (рекурсивно, битые APK пропускаются):

```
python -I patch_all.py "<папка с apk>" "<папка для результата>"
```

Один файл:

```
python -I patch_apk.py in.apk out.apk <папка_ключа>
python -I verify_apk.py in.apk out.apk -v
```

Ключ подписи создаётся при первом запуске в `<папка для результата>/_key` и потом переиспользуется.
Тогда пропатченный заново APK встанет поверх старого как обновление. Не теряйте его.

## Что меняется

* `AndroidManifest.xml`: только значение `targetSdkVersion` (правка на месте, 1 байт).
* `classes.dex`: точечные патчи того же размера, см. `fixes.py`. Каждый рецепт сначала сверяет
  метод с ожидаемыми инструкциями (иначе ошибка), после записи заново дизассемблирует метод
  и проверяет границы try-блоков и переходов.
  * `billing-explicit-intent`: `setPackage("com.android.vending")` для привязки к Google Play billing.
    С target 21 неявный Intent бросает `IllegalArgumentException` (это исправление Rovio сама
    сделала в Seasons 4.3.3 и Star Wars II 1.8.1).
  * `billing-unavailable`: в Go! и Transformers места под `setPackage` нет, поэтому
    `bindToIabService()` возвращает `false` («Google Play недоступен»).
  * `burstly-deviceid-null`: Space, вместо `getDeviceId()` подставляется `null`, иначе
    `SecurityException` без разрешения «Телефон».
  * `share-no-file-uri`: из «Поделиться» убрано вложение `file://` (`FileUriExposedException` с target 24).
  * `aiwu-killswitch-off`: отключена проверка подписи модера в Star Wars II Unlimited Credits.
* Подпись: старая удаляется, новая v1 (SHA-256) + v2.

`verify_apk.py` независимо проверяет результат: CRC всех файлов, совпадение содержимого
с оригиналом, валидность заголовка DEX и то, что изменились только ожидаемые методы,
подпись v1 (CMS через OpenSSL) и v2 (digest и подпись блока).

## Вспомогательное

* `inspect_apk.py`: манифест, ABI и подписи APK.
* `elfcheck.py`: нативные библиотеки (TEXTREL, зависимости от непубличных системных .so).
* `dexdis.py`: дизассемблер DEX в текст, удобный для grep.
