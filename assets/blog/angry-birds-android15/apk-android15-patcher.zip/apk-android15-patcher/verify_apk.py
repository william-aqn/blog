"""Independent verifier for a patched APK (does not import patch_apk).

Checks: zip integrity (CRC of every entry), content identical to the original except the
targetSdkVersion bytes, v1 JAR signature (digests + CMS via OpenSSL), v2 signature block
(structure, chunked digest, RSA signature via OpenSSL, cert/public-key match), alignment.
Usage: python -I verify_apk.py <original.apk> <patched.apk>
"""
import base64, hashlib, io, os, re, shutil, struct, subprocess, sys, tempfile, zipfile

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import axml

GIT_OPENSSL = r"C:\Program Files\Git\mingw64\bin\openssl.exe"
OPENSSL = os.environ.get("OPENSSL") or shutil.which("openssl") or GIT_OPENSSL
MIN_TARGET_SDK = 24  # Android 15 refuses to install anything lower
errors = []


def check(cond, msg):
    if not cond:
        errors.append(msg)
    return cond


def ossl(args, data=None):
    return subprocess.run([OPENSSL] + args, input=data, capture_output=True)


def parse_mf(text):
    """Java-manifest parse: returns (main_attrs, {name: attrs}, {name: raw_section_bytes})."""
    raw_sections = text.split(b"\r\n\r\n")
    out, raws, main = {}, {}, None
    for raw in raw_sections:
        if not raw.strip():
            continue
        lines = raw.split(b"\r\n")
        joined = []
        for l in lines:
            if l.startswith(b" "):
                joined[-1] += l[1:]
            else:
                joined.append(l)
        attrs = {}
        for l in joined:
            k, v = l.split(b": ", 1)
            attrs[k.decode()] = v.decode("utf-8")
        if main is None:
            main = attrs
        else:
            out[attrs["Name"]] = attrs
            raws[attrs["Name"]] = raw + b"\r\n\r\n"
    return main, out, raws


def dex_diff(name, a, b):
    """Independent check of a modified dex: valid header checksum + SHA-1, same size, and every
    changed byte lies inside the instruction array of a method whose listing changed."""
    from dexdis import Dex, disasm
    import zlib
    check(len(a) == len(b), name + ": size changed")
    check(b[:8] == a[:8], name + ": magic changed")
    check(struct.unpack_from("<I", b, 8)[0] == (zlib.adler32(b[12:]) & 0xFFFFFFFF), name + ": bad adler32")
    check(b[12:32] == hashlib.sha1(b[32:]).digest(), name + ": bad SHA-1 signature")
    da, db = Dex(a), Dex(b)
    diffs = [i for i in range(32, len(a)) if a[i] != b[i]]
    changed, covered = [], set()
    for (ca, _, dataa) in da.classes():
        for midx, acc, code in da.methods_of(dataa):
            if not code:
                continue
            regs, ins, insns, n, tries = da.code(code)
            if any(insns <= i < insns + n * 2 for i in diffs):
                la = disasm(da, insns, n)
                lb = disasm(db, insns, n)
                check(db.code(code)[4] == tries, name + ": try table changed")
                changed.append((da.method(midx), [t for _, t in la], [t for _, t in lb]))
                covered.update(i for i in diffs if insns <= i < insns + n * 2)
    check(len(covered) == len(diffs), name + ": %d changed bytes outside method code" % (len(diffs) - len(covered)))
    return changed


def main(orig_path, new_path):
    errors.clear()
    changed_methods = []
    orig = zipfile.ZipFile(orig_path)
    data = open(new_path, "rb").read()
    z = zipfile.ZipFile(io.BytesIO(data))
    bad = z.testzip()
    check(bad is None, "CRC error in %s" % bad)

    sigfiles = lambda n: n.upper().startswith("META-INF/") and n.count("/") == 1 and (
        n.upper().endswith((".SF", ".RSA", ".DSA", ".EC", "MANIFEST.MF")) or n[9:].upper().startswith("SIG-"))
    on = [n for n in orig.namelist() if not sigfiles(n)]
    nn = [n for n in z.namelist() if not sigfiles(n)]
    check(sorted(on) == sorted(nn), "entry set differs: missing=%s extra=%s" % (
        sorted(set(on) - set(nn))[:5], sorted(set(nn) - set(on))[:5]))
    check(sorted(n for n in z.namelist() if sigfiles(n)) == ["META-INF/CERT.RSA", "META-INF/CERT.SF", "META-INF/MANIFEST.MF"],
          "unexpected signature files")
    for n in on:
        a, b = orig.read(n), z.read(n)
        if n == "AndroidManifest.xml":
            diff = [i for i in range(len(a)) if a[i] != b[i]] if len(a) == len(b) else None
            check(diff is not None and len(diff) <= 4, "manifest changed more than expected: %r" % (diff and diff[:10]))
            pool, _, els = axml.parse(b)
            sdk = [e for e in els if e.name == "uses-sdk"][0]
            t = axml.get_attr(pool, sdk, 0x01010270)
            check(t.vdata >= MIN_TARGET_SDK and t.vtype == 0x10, "targetSdk below %d" % MIN_TARGET_SDK)
            target = t.vdata
        elif re.fullmatch(r"classes\d*\.dex", n) and a != b:
            changed_methods.extend(dex_diff(n, a, b))
        else:
            check(a == b, "content differs: " + n)
        ci_o, ci_n = orig.getinfo(n), z.getinfo(n)
        check(ci_o.compress_type == ci_n.compress_type or n == "AndroidManifest.xml", "compression changed: " + n)

    # alignment of stored entries
    for zi in z.infolist():
        if zi.compress_type == 0:
            nlen, xlen = struct.unpack_from("<HH", data, zi.header_offset + 26)
            start = zi.header_offset + 30 + nlen + xlen
            check(start % 4 == 0, "stored entry not 4-aligned: " + zi.filename)

    # ---- v1
    mf = z.read("META-INF/MANIFEST.MF")
    sf = z.read("META-INF/CERT.SF")
    rsa = z.read("META-INF/CERT.RSA")
    _, mfe, mfraw = parse_mf(mf)
    sfmain, sfe, _ = parse_mf(sf)
    files = [n for n in z.namelist() if not n.endswith("/") and not sigfiles(n)]
    check(sorted(mfe) == sorted(files), "MANIFEST.MF entry list mismatch")
    for n in files:
        d = base64.b64encode(hashlib.sha256(z.read(n)).digest()).decode()
        check(mfe.get(n, {}).get("SHA-256-Digest") == d, "v1 digest mismatch " + n)
        check(sfe.get(n, {}).get("SHA-256-Digest") == base64.b64encode(hashlib.sha256(mfraw[n]).digest()).decode(),
              "SF section digest mismatch " + n)
    check(sfmain.get("SHA-256-Digest-Manifest") == base64.b64encode(hashlib.sha256(mf).digest()).decode(),
          "SF whole-manifest digest mismatch")
    check(sfmain.get("X-Android-APK-Signed") == "2", "X-Android-APK-Signed missing")
    with tempfile.TemporaryDirectory() as td:
        open(os.path.join(td, "sf"), "wb").write(sf)
        open(os.path.join(td, "rsa"), "wb").write(rsa)
        r = ossl(["cms", "-verify", "-binary", "-inform", "DER", "-in", os.path.join(td, "rsa"),
                  "-content", os.path.join(td, "sf"), "-noverify", "-purpose", "any", "-out", os.devnull])
        check(r.returncode == 0, "v1 CMS verify failed: " + r.stderr.decode(errors="replace"))
        r = ossl(["cms", "-cmsout", "-print", "-inform", "DER", "-in", os.path.join(td, "rsa")])
        txt = r.stdout.decode(errors="replace")
        check(re.search(r"signedAttrs:\s*<ABSENT>", txt) is not None, "CMS has signed attributes (unexpected)")
        check(re.search(r"eContent:\s*<ABSENT>", txt) is not None, "CMS is not detached")
        v1_cert = ossl(["pkcs7", "-inform", "DER", "-in", os.path.join(td, "rsa"), "-print_certs"]).stdout

    # ---- v2
    eocd = data.rfind(b"PK\x05\x06")
    cd_size, cd_off = struct.unpack_from("<II", data, eocd + 12)
    check(eocd == cd_off + cd_size, "CD does not end at EOCD")
    check(data[cd_off - 16:cd_off] == b"APK Sig Block 42", "no APK Signing Block magic")
    size2 = struct.unpack_from("<Q", data, cd_off - 24)[0]
    blk_start = cd_off - size2 - 8
    size1 = struct.unpack_from("<Q", data, blk_start)[0]
    check(size1 == size2, "signing block size fields differ")
    p, end = blk_start + 8, cd_off - 24
    pairs = {}
    while p < end:
        ln = struct.unpack_from("<Q", data, p)[0]
        pid = struct.unpack_from("<I", data, p + 8)[0]
        pairs[pid] = data[p + 12:p + 8 + ln]
        p += 8 + ln
    check(p == end, "pair walk did not land on block end")
    check(0x7109871A in pairs, "no v2 block")

    def rd(b, o):
        n = struct.unpack_from("<I", b, o)[0]
        return b[o + 4:o + 4 + n], o + 4 + n

    signers, _ = rd(pairs[0x7109871A], 0)
    signer, o = rd(signers, 0)
    check(o == len(signers), "more than one signer")
    sd, o2 = rd(signer, 0)
    sigs, o2 = rd(signer, o2)
    pub, o2 = rd(signer, o2)
    digs, q = rd(sd, 0)
    certs, q = rd(sd, q)
    attrs, q = rd(sd, q)
    d1, _ = rd(digs, 0)
    alg = struct.unpack_from("<I", d1, 0)[0]
    dig, _ = rd(d1, 4)
    cert1, _ = rd(certs, 0)
    s1, _ = rd(sigs, 0)
    salg = struct.unpack_from("<I", s1, 0)[0]
    sig, _ = rd(s1, 4)
    check(alg == salg == 0x0103, "unexpected v2 alg %x/%x" % (alg, salg))

    # chunked digest computed independently
    eocd_mod = bytearray(data[eocd:])
    struct.pack_into("<I", eocd_mod, 16, blk_start)
    chunks = []
    for sec in (data[:blk_start], data[cd_off:eocd], bytes(eocd_mod)):
        for i in range(0, len(sec), 1048576):
            c = sec[i:i + 1048576]
            chunks.append(hashlib.sha256(b"\xa5" + struct.pack("<I", len(c)) + c).digest())
    calc = hashlib.sha256(b"\x5a" + struct.pack("<I", len(chunks)) + b"".join(chunks)).digest()
    check(calc == dig, "v2 content digest mismatch")
    with tempfile.TemporaryDirectory() as td:
        for nm, b in (("sd", sd), ("sig", sig), ("pub.der", pub), ("cert.der", cert1)):
            open(os.path.join(td, nm), "wb").write(b)
        r = ossl(["dgst", "-sha256", "-verify", os.path.join(td, "pub.der"), "-keyform", "DER",
                  "-signature", os.path.join(td, "sig"), os.path.join(td, "sd")])
        check(r.returncode == 0, "v2 RSA signature invalid: " + (r.stdout + r.stderr).decode(errors="replace"))
        cpub = ossl(["x509", "-inform", "DER", "-in", os.path.join(td, "cert.der"), "-pubkey", "-noout"]).stdout
        spub = ossl(["pkey", "-pubin", "-inform", "DER", "-in", os.path.join(td, "pub.der")]).stdout
        check(cpub.strip() == spub.strip() and cpub, "v2 cert public key != signer public key")
        c_pem = ossl(["x509", "-inform", "DER", "-in", os.path.join(td, "cert.der")]).stdout
        check(c_pem.strip() and c_pem.strip() in v1_cert, "v1 and v2 certificates differ")

    print(("PASS " if not errors else "FAIL ") + os.path.basename(new_path) +
          " entries=%d v2block=%dB dex-methods-changed=%d" % (len(z.namelist()), cd_off - blk_start, len(changed_methods)))
    if "-v" in sys.argv:
        for m, la, lb in changed_methods:
            print("   ~", m)
            import difflib
            for l in difflib.unified_diff(la, lb, lineterm="", n=0):
                if not l.startswith(("---", "+++", "@@")):
                    print("       ", l)
    for e in errors[:20]:
        print("   -", e)
    return not errors


if __name__ == "__main__":
    a = [x for x in sys.argv[1:] if x != "-v"]
    sys.exit(0 if main(a[0], a[1]) else 1)
